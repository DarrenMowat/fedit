{-
CS410 Advanced Functional Programming
Autumn 2010
-}

{- Practical 2: Fair is Foul and Foul is Fair -}

module Prac2 where

{-
You will also need the file FOUL.lhs, which contains the FOUL
interpreter we developed in lectures.
-}

import FOUL

{-****************************************************************-}
{- Your Identity                                                  -}
{-****************************************************************-}

{- Put your name instead of Harry's in the following String! -}

myName :: String
myName = "Harry Palmer"


{-
Your mission is in two parts: firstly to write programs which
work in FOUL, and secondly to write programs which break FOUL.
-}


{-****************************************************************-}
{- Part One --- Fair is Foul                                      -}
{-****************************************************************-}

{-
Construct a sorting algorithm in FOUL by adding functions to
the following empty program.
-}

sortProg :: Prog
sortProg = []

{-
I'm hoping that the following example (and others of its kind)
might produce sensible output eventually.
-}

mySort :: Val
mySort = eval sortProg []
  (EA "sort" [ EC ":" [ EC "Suc" [EC "Suc" [EC "Zero" []]]
              , EC ":" [ EC "Suc" [EC "Zero" []]
               , EC ":" [ EC "Suc" [EC "Suc" [EC "Suc" [EC "Zero" []]]]
                , EC ":" [ EC "Zero" []
                 , EC "[]" []
             ]]]]])

{-
Suggested steps to a solution

(1) Develop a comparison function, e.g. "less than";
(2) write the function to insert a number into a binary search tree;
(3) implement if-then-else as a function
(4) write the function to build a binary search tree up from empty
      by inserting the elements of a list, one by one, using comparison
      to keep the tree in order;
(5) write the function to append two lists;
(6) write the function to flatten a binary search tree, getting a list;
(7) make sort the function which builds a binary search tree from its input
      and then flattens it.

Feel free to choose a different algorithm, but make it sort.
-}

{-****************************************************************-}
{- Part Two --- Foul is Fair                                      -}
{-****************************************************************-}

{-
Show that my implementation of FOUL deserves to be described as "foul",
in that it can easily be persuaded to fail to return a value. More
particularly, implement a program
-}

badProg :: Prog
badProg = []

{- and a list of example expressions -}

badExamples :: [Expr]
badExamples = []

{- such that every element of -}

testBadExamples :: [Val]
testBadExamples = map (eval badProg []) badExamples

{- goes wrong in some way. -}

{-
Try to find as many different kinds of thing which can possibly go
wrong. Exercise as much wickedness as you can muster!
-}
