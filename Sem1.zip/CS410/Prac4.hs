module Main where

import Data.Char
import Control.Applicative
import Data.Traversable
import FOUL

{----
(0) IDENTIFY YOURSELF

Name: 

----}

newtype Parser x =
  Parser {parse :: String -> Either (String, String) (x, String)}

{----
(1) Define suitable instances of Applicative and Alternative to
support parsing. Use

  Left (e, s)   to indicate that input s was rejected with message e
  Right (x, s)  to indicate that x was successfully delivered, with
                  s the remainder of the input
----}

instance Applicative Parser where
  -- pure should succeed and consume no input
  -- <*> should parse the function, then the argument,
  --   and return the result of the application

instance Alternative Parser where
  -- empty should reject the input with no message
  -- <|> should succeed if possible; if both arguments fail,
  --   some attempt should be made to choose the more reasonable
  --   explanation (how might the length of the rejected input
  --   play a part? how might the message?)

{- I've provided a Functor instance for you: -}

instance Functor Parser where
  fmap = (<*>) . pure

{- Define a parser for a single character which must satisfy a given test. -}

char :: (Char -> Bool) -> Parser Char
char = undefined

{----
What does

  traverse (char . (==))

do, e.g., if you apply it to "fred"?
----}

{----
Define a parser which replaces the empty error message with a better one.

message :: String -> Parser x -> Parser x
message = undefined

You should make sure that

  message "barf" empty <|> empty == empty <|> message "barf" empty

and that both deliver the message "barf" rather than no message at all.
----}

{----
(2) Define parsers for tokens

Hint: you may find it useful to check out the operators

  many
  some

in the library documentation for Control.Applicative.
----}

space :: Parser ()
space = undefined -- this should ignore any amount of whitespace

variable :: Parser String
variable = undefined
  -- this should accept any sequence of alphanumeric characters
  -- beginning with a lower case letter

constructor :: Parser String
constructor = undefined
  -- this should accept any sequence of alphanumeric characters
  -- beginning with an upper case letter

{----
(3) Define a parser combinator for comma-separated lists in parentheses
----}

parenList :: Parser x -> Parser [x]
parenList p = undefined
  -- this should parse string (s1,s2,...,sn) as
  -- list [x1,x2,...,xn], if p parses each s as the corresponding x;
  -- be as liberal as you can about extra whitespace

{----
(4) Define parsers for FOUL expressions and patterns
----}

{--- remember
data Expr
  = EC String [Expr]  -- should look like    Con(e1,...,en)
  | EV String        -- should look like    x
  | EA String [Expr]  -- should look like    f(e1,...en)
  deriving Show
----}

parseExpr :: Parser Expr
parseExpr = undefined

{---- remember
data Pat
  = PC String [Pat]  -- should look like    Con(e1,...,en)
  | PV String        -- should look like    x
  deriving Show
----}

parsePat :: Parser Pat
parsePat = undefined

{----
(5) Define parsers for FOUL Line and whole FOUL programs
----}

{---- remember
type Line = ([Pat], Expr)
----}

parseLine :: Parser Line
parseLine = undefined

{---- remember
type Prog = [(String, [Line])]
----}

parseProg :: Parser Prog
parseProg = undefined

{----
(6) Wrap the whole thing in a function
----}

in2out :: String -> String
in2out = undefined

{----
which
  tries to parse its input as a FOUL program, and
    if all the input is successfully consumed,
      evaluates   EA "main" []
        and returns the output (you can use show for that)
    if the input does not parse or is not all consumed
      returns the error message

You'll need to paste in or otherwise link your FOUL interpreter.
----}

{----
(7) Try it!
----}

main :: IO ()
main = interact in2out

{----
If you compile this with ghc, you should get an executable
which takes FOUL programs from  stdin and sends the relevant response
to stdout!

  ghc --make -o foul Prac4.hs
  ./foul < mysort.foul
----}
